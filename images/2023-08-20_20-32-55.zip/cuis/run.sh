#!/bin/bash
SqueakLiveTyping.app/Contents/MacOS/Squeak CuisUniversity-5706.image