#!/bin/bash
Squeak-jit.app/Contents/MacOS/Squeak CuisUniversity-5481.image