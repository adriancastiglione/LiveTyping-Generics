#!/bin/bash
Squeak.app/Contents/MacOS/Squeak CuisUniversity-5481.image