# Morphic

A number of these classes have been refactored and placed into the _Cuis-Smalltalk-UI_ repo.  This is in concert with Cuis 6 Morphic class hierarchy refactor and Vector Graphics addition.  The examples here should still work with Cuis 5 images, but are unsusported.

Now depricated:
- 'Morphic-Misc1' 
- 'Morphic-Widgets-Extras'  [see 'Examples-Morphic']
- 'Morphic-ColorEditor'
- 'Morph-MetaProperties'
- 'Dice'

'Examples-Morphic' includes
-  Animator
-  FrameRateMorph
-  FunctionGraphMorph
-  MagnifierMorph
-  MorphMessageBox

For more examples please look at (and use!) _Cuis-Smalltalk-UI_
